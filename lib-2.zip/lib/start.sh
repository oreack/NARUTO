while true
do
echo "Starting NARUTO-MD!"
node .
done
